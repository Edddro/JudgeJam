import JudgeView from "@/components/judge-view"

export default function JudgePage() {
  return (
    <main className="min-h-screen bg-light-blue">
      <JudgeView />
    </main>
  )
}
