import JudgeJamInterface from "@/components/judge-jam-interface"

export default function Home() {
  return (
    <main className="min-h-screen bg-light-blue">
      <JudgeJamInterface />
    </main>
  )
}
